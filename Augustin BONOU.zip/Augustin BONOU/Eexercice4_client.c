#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet.h>
#include <netdb.h>
#include <string.h>
#define max 3000

int main()
{
	int s, a, t;
	struct hosten *adr_h;
	struct sockaddr_in serveur;
	
	char nom[100] = "";
	printf("\nEntrer le chemin du fichier que vous 		voulez envoyer");
	scanf("%s", nom);
	 
	//Remplissage de la structure serveur
	serveur.sin_family = AF_INET;
	serveur.sin_port = htons(2502);

	//Creation de la socket
	if((s=socket(AF_INET, SOCK_STREAM,0))<0)
	{
		perror("\nErreur Socket");
	}
	else
	{
		printf("Socket créé");
	}
		
	//Construction de l'adresse
	if((adr_h = gethotbyname("127.0.0.1"))==0)
	{
		perror("\nErreur Socket");
	}
	else
        {
		bcopy((char*)adr_h->h_addr, (char*)&serveur.sin_addr, adr_h->h_length);
	}	
	
	//Connexion au serveur
	if(connect(s, (struct sockaddr*)&serveur, sizeof(seveur))<0)
	{
		perror("\nEchec connexion");
	}
	else
	{
		FILE* f = fopen(nom, "r+");
		char v;
		do
	{
		v=fgetc(f);
		t=send(s,(const char*)&v, sizeof(v),0);
	}while(v!EOF);
	close(f);
	printf("Fichier envoyé");
	}
	close(s);
}
