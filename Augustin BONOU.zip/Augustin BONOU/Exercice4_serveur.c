#include <stdio.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <string.h>

#define max 3000

int main()
{
	int s, a, b, c, r, longueur;
	struct sockaddr_in serveur, client;
	struct hosten *adr_h;

//Remplissage de la structure serveur
	serveur.sin_family = AF_INET;
	serveur.sin_addr.s_addr = INADDR_ANY;
	serveur.sin_port = htons(2502);

	if((s=socket(AF_INET, SOCK_STREAM,0)) == -1)
	{
		perror("\nBind : ");
	}
	else
	{	
		printf("Bind réussi");
	}

//Construction de l'addresse
	adr_h = gethostbyname("127.0.0.1");
	bcopy((char* )adr_h->h_addr, (char*)&serveur.sin_addr, adr_h->h_length);

//La connexion

	listen(s,1) //une connexion au maximum
	printf("Le serveur attend une connexion");
	
	longeur = sizeof(client);
	if((c=accept(s,(struct sockaddr*)&client, &longueur))<0)
	{
		perror("Connexion echoué");
	}
	else
	{
		printf("Connexion réusssie") //Communication avec le client
		char[1000]="";
		printf("Entrez le chemin où vous voulez enrégistrer fichier");
		scanf("%s", nom);
		FILE* f = fopen(nom, "w+");//Creer le fichier local avec le nom indiqué
		char v[0]; //Variable de la reception
		do
		{
			recv(c, v, 1, 0);
			if(v[0] == EOF)
				{
					break;
				}
			fputs(v,f);
		}while(1);
		close(f);
		printf("Fichier bien recu\n\n");
	}
	close(c);
	close(s);
}
