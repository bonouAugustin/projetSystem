#include <sys/types.h>
#include <signal.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

	int main(int argc, char const *argv[])
	{

		//la creation du premier processus
		pid_fils fils1;
		fils1 = fork();
		if (fils1 == 0)
		{
			printf("Je suis le fils du pid %d", getpid());//affichage de pid
			return 0;
		}
		else
		{
			printf("Erreur de creation du processus 1");
		}
		
		//la creation du deuxieme processus
		pid_fils fils2;
		fils2 = fork();

		if (fils2 == 0)
		{
			printf("Je suis le fils du pid %d", getpid());//affichage de pid
			return 0;
		}
		else
		{
			printf("Erreur de creation du processus 2");
		}

		//la creation du troisieme processus
		pid_fils fils3;
		fils2 = fork();

		if (fils3 == 0)
		{
			printf("Je suis le fils du pid %d", getpid());//affichage de pid
			return 0;
		}
			
		return 0;
	}

